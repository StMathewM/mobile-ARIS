# android-bottom-navigation-with-tablayout-with-navigation-drawer
Sample android java project with side navigation drawer, bottom navigation and tablayout presented at some navigation position. A ViewPager is placed inside the Home Fragment.

| <img src="https://github.com/radioacoustick/android-bottom-navigation-with-tablayout-with-navigation-drawer/blob/master/screenshots/Screenshot_20220113_191415.png" width="350"> | <img src="https://github.com/radioacoustick/android-bottom-navigation-with-tablayout-with-navigation-drawer/blob/master/screenshots/Screenshot_20220113_191536.png" width="350"> |

| <img src="https://github.com/radioacoustick/android-bottom-navigation-with-tablayout-with-navigation-drawer/blob/master/screenshots/Screenshot_20220113_191545.png" width="350"> | <img src="https://github.com/radioacoustick/android-bottom-navigation-with-tablayout-with-navigation-drawer/blob/master/screenshots/Screenshot_20220113_191550.png" width="350"> |

| <img src="https://github.com/radioacoustick/android-bottom-navigation-with-tablayout-with-navigation-drawer/blob/master/screenshots/Screenshot_20220113_191556.png" width="350"> | <img src="https://github.com/radioacoustick/android-bottom-navigation-with-tablayout-with-navigation-drawer/blob/master/screenshots/Screenshot_20220113_191622.png" width="350"> |
